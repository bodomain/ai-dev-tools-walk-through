import SnakeGame from './SnakeGame.jsx'

export default function App() {
  return (
    <div className="p-4">
      <SnakeGame />
    </div>
  )
}
